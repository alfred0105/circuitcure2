# Pin-only PCB connectivity dataset

This generated dataset turns each source board into a wire-free input plus separately stored connection labels.

## Contents

- `boards/*.pin_only.brd` and `boards/*.pin_only.kicad_pcb`: placed component footprints and their pad/pin geometry remain; routed signals/tracks and net assignments are removed. Board outlines remain where present.
- `graphs.jsonl`: one NetworkX candidate graph per board. Nodes describe component/pad IDs, locations, rotations, side, pad shape/size, and heuristic component type. Its stored baseline candidates use only cKDTree geometry: within 25 mm or among each node's 8 nearest eligible pins. Same-component pin pairs are excluded. The graph input contains no edge labels or net names.
- `edge_labels.jsonl`: supervised target labels keyed by `graph_id` and `edge_id`. Join this only in the training loader; `label=1` means both pads belong to the same original electrical net, and `label=0` means they do not. It also retains all cross-component truth pairs and anonymized net groups, including positives that candidate generation missed, so candidate recall can be measured honestly.
- `dataset_manifest.json`: counts, source references, splits, exclusions, and per-board paths.

The split is grouped by source repository to reduce design leakage. The 19 requested component classes are inferred from reference/value/footprint text; ambiguous components are marked `unknown`. The target describes same-net connectivity, which may represent an indirect path through other components rather than one literal copper segment.

`scripts/benchmark_pcb_pin_connectivity.py` re-generates candidates from the pin coordinates for four wider radius/k settings, selects the lowest-cost setting within 0.5 percentage points of best validation recall (and no more than 150 average candidates per pin), then trains LightGBM and a CUDA GNN using only this PCB-derived dataset. It also reports candidate-oracle Recall@5 and thresholded connected-component net reconstruction metrics.

Current source pass: 193 deduplicated board files were inspected; boards without component pads or cross-component connection labels are excluded. Candidate generation uses `--radius-mm` and `--k-nearest` options in `scripts/prepare_pin_only_pcb_dataset.py`.
